unsigned long long codificar(unsigned int a);
unsigned int decodificar(long long a, int b);
unsigned int ligarBit(unsigned int a, int bit);
unsigned int desligarBit(unsigned int a, int bit);
bool testarBit(unsigned int a, int bit);