unsigned int armazena(int a, int b, int c, int d);
unsigned int soma(int a, int b, int c);
unsigned int mult(int a, int b, int c);
unsigned short primeiro(int a);
unsigned short segundo(int a);
unsigned short terceiro(int a);
unsigned short quarto(int a);
